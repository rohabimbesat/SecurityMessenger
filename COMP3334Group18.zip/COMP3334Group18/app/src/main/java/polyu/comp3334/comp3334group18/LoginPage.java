package polyu.comp3334.comp3334group18;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class LoginPage extends AppCompatActivity {
    private EditText edEmail, edPassword;
    private FirebaseAuth firebaseAuth;
    private SecurityCollection securityCollection;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        securityCollection = new SecurityCollection();

        edEmail = findViewById(R.id.edEmail);
        edPassword = findViewById(R.id.edPassword);
        firebaseAuth = FirebaseAuth.getInstance();

        // user  has logged in before and haven't  log out
        if (firebaseAuth.getCurrentUser() != null) {
            Intent intent = new Intent(LoginPage.this, Home.class);
            startActivity(intent);
            finish();
        }

    }

    public void login(View view) {
        if (TextUtils.isEmpty(edEmail.getText())) {
            edEmail.setError("Email required");
        } else if (TextUtils.isEmpty(edPassword.getText())) {
            edPassword.setError("Password required");

        } else {
            final ProgressDialog progress = new ProgressDialog(this);
            progress.setMessage("Loading...");
            progress.show();

            String hashedPwd = securityCollection.hashThePassword(edPassword.getText().toString());
            Log.i("LoginPage.java", "Hashed Password: " + hashedPwd);
            firebaseAuth.signInWithEmailAndPassword(edEmail.getText().toString(), hashedPwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        // login success
                        FirebaseUser baseUser = firebaseAuth.getCurrentUser();

                        // get the database branch name of the current user
                        String root = "";
                        int position = baseUser.getEmail().indexOf("@");
                        if (position != -1) {
                            root = baseUser.getEmail().substring(0, position);
                        }

                        // update the login status
                        DatabaseReference baseReference = FirebaseDatabase.getInstance().getReference("Users").child(root).child("LoginStatus");
                        baseReference.setValue("Yes");

                        Toast.makeText(LoginPage.this, "Welcome Back", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(LoginPage.this, Home.class);
                        startActivity(intent);
                        finish();

                    } else {
                        // If sign in fails, display a message to the user.
                        Toast.makeText(LoginPage.this, "Your email or password is wrong", Toast.LENGTH_LONG).show();
                        progress.dismiss();
                    }
                }
            });
            progress.dismiss();
        }
    }


    public void signup(View view) {
        Intent intent = new Intent(LoginPage.this, SignUpPage.class);
        startActivity(intent);
    }
}
