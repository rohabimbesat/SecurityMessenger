package polyu.comp3334.comp3334group18;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class SignUpPage extends AppCompatActivity {
    EditText edName, edEmail, edPassword, edConfirmPassword;
    Dialog instruction;

    private FirebaseAuth baseReference;
    private FirebaseUser baseUser;
    private ProgressDialog progress;

    private SecurityCollection securityCollection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page);

        securityCollection = new SecurityCollection();

        edName = findViewById(R.id.edName);
        edEmail = findViewById(R.id.edEmail);
        edPassword = findViewById(R.id.edPassword);
        edConfirmPassword = findViewById(R.id.edConfirmPassword);
        instruction = new Dialog(this);
        baseReference = FirebaseAuth.getInstance();
        progress = new ProgressDialog(this);

    }


    public void signup(View view) {
        if (TextUtils.isEmpty(edName.getText())) {
            edEmail.setError("Name required");
        } else if (TextUtils.isEmpty(edEmail.getText())) {
            edEmail.setError("Email required");
        } else if (TextUtils.isEmpty(edPassword.getText())) {
            edPassword.setError("Password required");
        } else if (TextUtils.isEmpty(edConfirmPassword.getText())) {
            edPassword.setError("Confirm password is required");
        } else if (edPassword.getText().toString().length() < 8) {
            Toast.makeText(SignUpPage.this, "Passwords is too short", Toast.LENGTH_LONG).show();
        } else if (!edConfirmPassword.getText().toString().equals(edPassword.getText().toString())) {
            Toast.makeText(SignUpPage.this, "Passwords must match", Toast.LENGTH_LONG).show();
        } else if (!(checkPasswordSecurity(edPassword.getText().toString()))) {
            Toast.makeText(SignUpPage.this, "The password is not secure", Toast.LENGTH_LONG).show();
        } else {

            progress.setMessage("Loading...");
            progress.show();
            register(edEmail.getText().toString(), edName.getText().toString(), edPassword.getText().toString());
        }
    }

    public void register(String email, final String name, String password) {
        String hashedPwd = securityCollection.hashThePassword(password);
        Log.i("SignUpPage.java", "Hashed Password: " + hashedPwd);

        baseReference.createUserWithEmailAndPassword(email, hashedPwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // register success
                    progress.dismiss();
                    baseUser = baseReference.getCurrentUser();

                    String root = "";
                    int position = baseUser.getEmail().indexOf("@");
                    if (position != -1) {
                        root = baseUser.getEmail().substring(0, position);
                    }

                    //  add a database branch  for the current user
                    DatabaseReference nameReference = FirebaseDatabase.getInstance().getReference("Users").child(root);
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put("id", baseUser.getUid());
                    hashMap.put("Email", baseUser.getEmail());
                    hashMap.put("Name", name);
                    hashMap.put("LoginStatus", "Yes");
                    hashMap.put("Invitation", "");
                    hashMap.put("Message", "");
                    hashMap.put("MAC", "");
                    hashMap.put("AESKey", "");
                    hashMap.put("PublicKey", "");

                    nameReference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(SignUpPage.this, "Welcome", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(SignUpPage.this, Home.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    });

                } else {
                    Toast.makeText(SignUpPage.this, "Register fail! Please try again", Toast.LENGTH_LONG).show();
                    progress.dismiss();
                }

            }
        });
    }

    public boolean checkPasswordSecurity(String password) {
        boolean number = false, uppercase = false, lowercase = false;
        char[] pwd = password.toCharArray();
        for (int i = 0; i < pwd.length; i++) {
            int pwdASCII = (int) pwd[i];
            if (pwdASCII >= 65 && pwdASCII <= 90) {
                uppercase = true;
            } else if (pwdASCII >= 97 && pwdASCII <= 122) {
                lowercase = true;
            } else if (pwdASCII >= 48 && pwdASCII <= 57) {
                number = true;
            }

            if (number && uppercase && lowercase) {
                return true;
            }
        }
        return false;
    }

    public void openInstruction(View view) {
        instruction.setContentView(R.layout.instruction_dialog);
        instruction.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        instruction.show();
    }

    public void closeInstruction(View view) {
        instruction.dismiss();
    }
}
