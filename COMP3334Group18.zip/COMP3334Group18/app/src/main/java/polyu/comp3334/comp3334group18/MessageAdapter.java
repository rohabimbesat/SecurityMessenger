package polyu.comp3334.comp3334group18;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {


    private static int send = 1;
    private static int receive = 2;
    private Context context;
    private List<MessageRecord> message;


    public MessageAdapter(Context context, List<MessageRecord> message) {
        this.context = context;
        this.message = message;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int type) {
        View view;
        if (type == send) {
            view = LayoutInflater.from(context).inflate(R.layout.send_chat_item, viewGroup, false);

        } else {
            view = LayoutInflater.from(context).inflate(R.layout.receive_chat_item, viewGroup, false);
        }
        return new MessageAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageAdapter.ViewHolder viewHolder, int i) {
        MessageRecord record = message.get(i);

        viewHolder.message_box.setText(record.getMessage());
    }

    @Override
    public int getItemViewType(int position) {

        if (message.get(position).getSend_type() == send) {
            return send;
        } else {
            return receive;
        }
    }

    @Override
    public int getItemCount() {
        return message.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView message_box;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            message_box = itemView.findViewById(R.id.chat_message);
        }
    }
}
