package polyu.comp3334.comp3334group18;

public class MessageRecord {
    private int send_type;
    private String message;

    public MessageRecord(String message, int send_type) {
        this.message = message;
        this.send_type = send_type;
    }

    public int getSend_type() {
        return send_type;
    }

    public void setSend_type(int send_type) {
        this.send_type = send_type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
