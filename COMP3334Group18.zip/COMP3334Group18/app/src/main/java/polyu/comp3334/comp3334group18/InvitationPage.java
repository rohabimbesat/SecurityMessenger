package polyu.comp3334.comp3334group18;

import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class InvitationPage extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser baseUser;
    private DatabaseReference reference;
    private DatabaseReference referenceForInvitation;
    private DatabaseReference userLoginReference;
    private ValueEventListener listenerForInvitation;
    private ValueEventListener listenerForLoginStatus;
    private Handler handler;
    private static final long time = 1000;

    EditText target_invitee;
    TextView sent_request;
    TextView received_request;

    Button SendRequest;
    Button AcceptRequest;
    Button RejectRequest;
    Button chatButton;

    String root = "";
    String receiver = "";
    String isLogin = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invitation);

        mAuth = FirebaseAuth.getInstance();
        baseUser = mAuth.getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");


        target_invitee = (EditText) findViewById(R.id.target_invitee);
        sent_request = (TextView) findViewById(R.id.sent_request);
        received_request = (TextView) findViewById(R.id.received_request);


        SendRequest = (Button) findViewById(R.id.SendRequest);
        AcceptRequest = (Button) findViewById(R.id.AcceptRequest);
        RejectRequest = (Button) findViewById(R.id.RejectRequest);
        chatButton = (Button) findViewById(R.id.chat);

        AcceptRequest.setEnabled(false);
        RejectRequest.setEnabled(false);


        chatButton.setEnabled(false);


        // get database root name
        int position = baseUser.getEmail().indexOf("@");
        if (position != -1) {
            root = baseUser.getEmail().substring(0, position);
        }

        referenceForInvitation = reference.child(root).child("Invitation");


    }

    public void onStart() {
        super.onStart();

        SendRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendInvitation();
            }
        });

        AcceptRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference replyRequest = reference.child(receiver).child("Invitation");
                replyRequest.setValue("Accept");
                received_request.setText("Request has been accepted");
                AcceptRequest.setEnabled(false);
                AcceptRequest.setVisibility(View.GONE);
                RejectRequest.setEnabled(false);
                RejectRequest.setVisibility(View.GONE);
                chatButton.setEnabled(true);
                chatButton.setVisibility(View.VISIBLE);
            }
        });

        RejectRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference replyRequest = reference.child(receiver).child("Invitation");
                replyRequest.setValue("Reject");
                referenceForInvitation.setValue("");
                received_request.setText("Invitation has been rejected");
                SendRequest.setEnabled(true);
                AcceptRequest.setEnabled(false);
                RejectRequest.setEnabled(false);
                AcceptRequest.setVisibility(View.GONE);
                RejectRequest.setVisibility(View.GONE);
            }
        });

        chatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), MessagingPage.class);
                intent.putExtra("SenderName", root);
                intent.putExtra("ReceiverName", receiver);
                startActivity(intent);
                finish();
            }
        });

        // for invitation function
        listenerForInvitation = referenceForInvitation.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // reply invitation
                    String value = dataSnapshot.getValue().toString();
                    String a = "";

                    if (value.equals("Reject")) {
                        referenceForInvitation.setValue("");
                        sent_request.setText("Request is rejected");
                        SendRequest.setEnabled(true);
                    } else if (value.equals("Accept")) {
                        // go to chat function
                        sent_request.setText("Request is accepted");
                        SendRequest.setEnabled(false);
                        chatButton.setEnabled(true);
                        chatButton.setVisibility(View.VISIBLE);
                    } else if (!(value.equals(""))) {
                        // reply invitation
                        receiver = value;
                        received_request.setText("Received invitation from: " + value);

                        SendRequest.setEnabled(false);
                        AcceptRequest.setEnabled(true);
                        AcceptRequest.setVisibility(View.VISIBLE);
                        RejectRequest.setEnabled(true);
                        RejectRequest.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void onDestroy() {
        super.onDestroy();

        if (referenceForInvitation != null) {
            referenceForInvitation.removeEventListener(listenerForInvitation);
        }


        if (userLoginReference != null) {
            userLoginReference.removeEventListener(listenerForLoginStatus);
        }

        DatabaseReference rootReference = FirebaseDatabase.getInstance().getReference("Users").child(root);
        rootReference.child("Invitation").setValue("");
        rootReference.child("AESKey").setValue("");
        rootReference.child("Message").setValue("");
        rootReference.child("PublicKey").setValue("");
        rootReference.child("MAC").setValue("");

        /*
        DatabaseReference receiverReference = FirebaseDatabase.getInstance().getReference("Users").child(receiver);
        receiverReference.child("Invitation").setValue("");
        receiverReference.child("AESKey").setValue("");
        receiverReference.child("PublicKey").setValue("");
        receiverReference.child("Message").setValue("");
        receiverReference.child("MAC").setValue("");
*/
    }

    public void CheckUserLoginStatus(String root) {
        userLoginReference = FirebaseDatabase.getInstance().getReference("Users").child(root).child("LoginStatus");
        listenerForLoginStatus = userLoginReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    isLogin = dataSnapshot.getValue().toString();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });


    }

    public void sendInvitation() {

        receiver = target_invitee.getText().toString();

        if (receiver.equals(root)) {
            // user entered self username
            Toast.makeText(InvitationPage.this, "You can't chat with yourself", Toast.LENGTH_LONG).show();
        } else if (receiver.equals("")) {
            Toast.makeText(InvitationPage.this, "Please enter an username", Toast.LENGTH_LONG).show();
        } else {
            CheckUserLoginStatus(receiver);

            // wait 1sec for server response
            handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    if (isLogin.equals("Yes")) {
                        //  send invitation to receiver
                        DatabaseReference receiverRef = reference.child(receiver).child("Invitation");
                        // tell the receiver who is the sender
                        receiverRef.setValue(root);
                        SendRequest.setEnabled(false);
                        sent_request.setText("Request is sent to: " + receiver);
                    } else {
                        // user is not in login state
                        Toast.makeText(InvitationPage.this, "Receiver not exist/not online", Toast.LENGTH_LONG).show();
                    }

                }
            }, time);

        }
    }

}
