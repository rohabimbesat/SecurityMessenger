package polyu.comp3334.comp3334group18;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.logging.Level;
import java.util.logging.Logger;

import android.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class SecurityCollection {

    // password hashing using SHA-256
    public String hashThePassword(String password) {
        String hashedValue = "";
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            byte[] output = d.digest(password.getBytes("UTF-8"));
            hashedValue = bytesToHex(output);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return hashedValue;
    }

    // generate 256 bit AES key and return the hex string
    public String generateAESKey() {
        String key = "";
        SecretKey secretKey;

        try {
            secretKey = KeyGenerator.getInstance("AES").generateKey();
            if (secretKey != null) {
                byte[] a = secretKey.getEncoded();
                key = bytesToHex(a);

            }
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(SecurityCollection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return key;
    }

    // byte array to hex string
    public String bytesToHex(byte[] input) {
        BigInteger number = new BigInteger(1, input);
        StringBuilder hex = new StringBuilder(number.toString(16));
        while (hex.length() < 32) {
            hex.insert(0, '0');
        }
        return hex.toString();
    }

    // convert the hex string to byte array
    public byte[] hexToBytes(String input) {
        byte[] byteArray = new byte[input.length() / 2];

        for (int i = 0; i < input.length(); i += 2) {
            int ans = Integer.parseInt(input.substring(i, i + 2), 16);
            byteArray[i / 2] = (byte) ans;
        }
        return byteArray;
    }

    // generate RSA key pair
    public KeyPair generateKeyPair() {
        KeyPair keyPair;
        try {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(1024, new SecureRandom());
            keyPair = generator.generateKeyPair();
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(SecurityCollection.class.getName()).log(Level.SEVERE, null, ex);
            keyPair = null;
        }
        return keyPair;
    }

    // convert public key to string
    public String publicKeyToString(PublicKey publicKey) {
        String string = "";
        KeyFactory factory;
        try {
            factory = KeyFactory.getInstance("RSA");
            X509EncodedKeySpec spec;
            spec = factory.getKeySpec(publicKey, X509EncodedKeySpec.class);
            string = Base64.encodeToString(spec.getEncoded(), Base64.DEFAULT);
        } catch (Exception ex) {
            Logger.getLogger(SecurityCollection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return string;
    }

    // convert string to public key
    public PublicKey stringToPublicKey(String string) {
        PublicKey publicKey;
        byte[] keyBytes;
        try {
            keyBytes = Base64.decode(string, Base64.DEFAULT);
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
            KeyFactory factory;
            factory = KeyFactory.getInstance("RSA");
            publicKey = factory.generatePublic(keySpec);
            //return publicKey;
        } catch (Exception ex) {
            Logger.getLogger(SecurityCollection.class.getName()).log(Level.SEVERE, null, ex);
            publicKey = null;
        }
        return publicKey;
    }

    // encrypt string
    public String encrypt(String string, PublicKey publicKey) {
        String cipherText = "";
        Cipher encryptCipher;
        try {
            encryptCipher = Cipher.getInstance("RSA");
            encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] cipherByte = encryptCipher.doFinal(string.getBytes("UTF-8"));
            cipherText = Base64.encodeToString(cipherByte, Base64.DEFAULT);
        } catch (Exception ex) {
            Logger.getLogger(SecurityCollection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cipherText;
    }

    // decrypt string or encrypted AES Key
    public String decrypt(String cipherText, PrivateKey privateKey) {
        String string = "";
        byte[] bytes = Base64.decode(cipherText, Base64.DEFAULT);
        Cipher decryptCipher;
        try {
            decryptCipher = Cipher.getInstance("RSA");
            decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
            string = new String(decryptCipher.doFinal(bytes), "UTF-8");
        } catch (Exception ex) {
            Logger.getLogger(SecurityCollection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return string;
    }

    // Decrypt cipherAesKey and generate MAC
    public String generateMAC(String cipherText, String AESKey) {
        String MAC = "";
        try {
            // rebuild SecretKey
            byte[] decodedKeyByte = Base64.decode(AESKey, Base64.DEFAULT);
            SecretKey AesKey = new SecretKeySpec(decodedKeyByte, "HMACSHA256");
            Mac mac = Mac.getInstance("HMACSHA256");
            mac.init(AesKey);
            byte[] macByte = mac.doFinal(cipherText.getBytes());
            MAC = Base64.encodeToString(macByte, Base64.DEFAULT);
        } catch (Exception ex) {
            Logger.getLogger(SecurityCollection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return MAC;
    }

    // Decrypt cipherAesKey and verify MAC
    public boolean isValidMAC(String cipherText, String cipherAESKey, PrivateKey privateKey, String receivedMAC) {
        Boolean isValid = false;

        // generate MAC with local decrypted aesKey again to verify receivedMAC
        String AESKey = decrypt(cipherAESKey, privateKey);
        String verifyMAC = generateMAC(cipherText, AESKey);
        if (verifyMAC.equals(receivedMAC) && !verifyMAC.equals("")) {
            isValid = true;
        }
        return isValid;
    }
}
