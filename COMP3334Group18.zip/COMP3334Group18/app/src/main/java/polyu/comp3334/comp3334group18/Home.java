package polyu.comp3334.comp3334group18;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Home extends AppCompatActivity {
    private TextView tvName;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    private String rootName;
    private DatabaseReference baseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        tvName = findViewById(R.id.tvName);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();

        // get the database branch name of the current user
        int position = firebaseUser.getEmail().indexOf("@");
        if (position != -1) {
            rootName = firebaseUser.getEmail().substring(0, position);
        }

        baseReference = FirebaseDatabase.getInstance().getReference("Users").child(rootName);

        if (firebaseUser != null) {
            setUserName();
        }


    }

    public void setUserName() {
        baseReference.child("Name").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                tvName.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void logout(View view) {
        ProgressDialog progress = new ProgressDialog(this);
        progress.setMessage("Loading...");
        progress.show();


        DatabaseReference baseReference = FirebaseDatabase.getInstance().getReference("Users").child(rootName);
        baseReference.child("LoginStatus").setValue("No");
        baseReference.child("Invitation").setValue("");
        baseReference.child("AESKey").setValue("");
        baseReference.child("Message").setValue("");
        baseReference.child("PublicKey").setValue("");
        baseReference.child("MAC").setValue("");
        firebaseAuth.signOut();
        progress.dismiss();


        Intent intent = new Intent(Home.this, LoginPage.class);
        startActivity(intent);
        finish();

    }


    public void goToMainActivity(View view) {
        Intent intent = new Intent(Home.this, InvitationPage.class);
        startActivity(intent);
    }
}
