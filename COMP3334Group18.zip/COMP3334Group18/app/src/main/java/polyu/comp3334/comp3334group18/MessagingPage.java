package polyu.comp3334.comp3334group18;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Handler;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.KeyPair;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;


public class MessagingPage extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private DatabaseReference reference;


    private DatabaseReference referenceForRootMessage;
    private DatabaseReference referenceForRootPublicKey;
    private DatabaseReference referenceForReceiverPublicKey;
    private DatabaseReference referenceForRootAESKey;
    private DatabaseReference referenceForRootMAC;


    private ValueEventListener listenerForRootMessage;
    private ValueEventListener listenerForRootPublicKey;
    private ValueEventListener listenerForReceiverPublicKey;
    private ValueEventListener listenerForRootAESKey;
    private ValueEventListener listenerForRootMAC;


    private SecurityCollection securityCollection;
    private Handler handler;
    private static final long time = 1000;

    String root = "";
    String receiver = "";

    TextView receiverName;
    EditText chat_message;
    ImageButton send_button;

    String AESKey;
    String receivedMAC;
    PublicKey rootPublicKey;
    PublicKey receiverPublicKey;
    KeyPair keyPair;

    MessageAdapter mAdapter;
    List<MessageRecord> record;
    RecyclerView recyclerView;
    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_messaging_page);

        mAuth = FirebaseAuth.getInstance();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        securityCollection = new SecurityCollection();

        receiverName = (TextView) findViewById(R.id.receiverName);
        chat_message = (EditText) findViewById(R.id.chat_message);
        send_button = (ImageButton) findViewById(R.id.send_message);

        root = getIntent().getStringExtra("SenderName");
        receiver = getIntent().getStringExtra("ReceiverName");
        receiverName.setText(receiver);

        referenceForRootPublicKey = reference.child(root).child("PublicKey");
        referenceForReceiverPublicKey = reference.child(receiver).child("PublicKey");
        referenceForRootAESKey = reference.child(root).child("AESKey");
        referenceForRootMAC = reference.child(root).child("MAC");
        referenceForRootMessage = reference.child(root).child("Message");

        context = this;
        record = new ArrayList<MessageRecord>();
        recyclerView = findViewById(R.id.my_recycler_view);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        mAdapter = new MessageAdapter(context, record);
        recyclerView.setAdapter(mAdapter);

        // for public key (root)
        listenerForRootPublicKey = referenceForRootPublicKey.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // received public key
                    String value = dataSnapshot.getValue().toString();
                    if (value.equals("Public")) {
                        keyPair = securityCollection.generateKeyPair();
                        rootPublicKey = keyPair.getPublic();
                        DatabaseReference publicKeyReference = FirebaseDatabase.getInstance().getReference("Users").child(root);
                        String publicKey = securityCollection.publicKeyToString(keyPair.getPublic());
                        publicKeyReference.child("PublicKey").setValue(publicKey);
                        Log.i("MessagingPage.java", "Public key of " + root + ": " + publicKey);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        // for public key (receiver update)
        listenerForReceiverPublicKey = referenceForReceiverPublicKey.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // received public key
                    String value = dataSnapshot.getValue().toString();
                    if (!value.equals("Public") && !value.equals("")) {
                        receiverPublicKey = securityCollection.stringToPublicKey(value);
                        Log.i("MessagingPage.java", "Public key of " + receiver + ": " + value);
                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        // for AESKey (root)
        listenerForRootAESKey = referenceForRootAESKey.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String value = dataSnapshot.getValue().toString();
                    if (!value.equals("")) {
                        AESKey = value;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        // for MAC (root)
        listenerForRootMAC = referenceForRootMAC.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String value = dataSnapshot.getValue().toString();
                    if (!value.equals("")) {
                        receivedMAC = value;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        listenerForRootMessage = referenceForRootMessage.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String value = dataSnapshot.getValue().toString();
                    if (!value.equals("")) {
                        String message;
                        if (securityCollection.isValidMAC(value, AESKey, keyPair.getPrivate(), receivedMAC)) {
                            message = securityCollection.decrypt(value, keyPair.getPrivate());
                        } else {
                            message = "You received a fake message";
                        }
                        MessageRecord messageRecord = new MessageRecord(message, 2);
                        record.add(messageRecord);
                        recyclerView.smoothScrollToPosition(record.size() - 1);
                        mAdapter.notifyDataSetChanged();

                        // remove every key from server
                        referenceForRootMessage.setValue("");
                        referenceForRootAESKey.setValue("");
                        referenceForRootMAC.setValue("");
                        referenceForRootPublicKey.setValue("");
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();

        send_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                keyPair = securityCollection.generateKeyPair();
                rootPublicKey = keyPair.getPublic();
                DatabaseReference publicKeyRootReference = FirebaseDatabase.getInstance().getReference("Users").child(root);
                publicKeyRootReference.child("PublicKey").setValue(securityCollection.publicKeyToString(keyPair.getPublic()));

                DatabaseReference publicKeyReceiverReference = FirebaseDatabase.getInstance().getReference("Users").child(receiver);
                publicKeyReceiverReference.child("PublicKey").setValue("Public");

                handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        if (rootPublicKey != null && receiverPublicKey != null) {
                            sendMessage();
                        } else {
                            Toast.makeText(MessagingPage.this, "failed to obtain public key from receiver in 1sec", Toast.LENGTH_SHORT).show();
                        }

                    }
                }, time);

            }
        });
    }

    public void onDestroy() {
        super.onDestroy();

        if (referenceForRootPublicKey != null) {
            referenceForRootPublicKey.removeEventListener(listenerForRootPublicKey);
        }

        if (referenceForReceiverPublicKey != null) {
            referenceForReceiverPublicKey.removeEventListener(listenerForReceiverPublicKey);
        }

        if (referenceForRootAESKey != null) {
            referenceForRootAESKey.removeEventListener(listenerForRootAESKey);
        }

        if (referenceForRootMAC != null) {
            referenceForRootMAC.removeEventListener(listenerForRootMAC);
        }

        if (listenerForRootMessage != null) {
            referenceForRootMessage.removeEventListener(listenerForRootMessage);
        }


        DatabaseReference rootReference = FirebaseDatabase.getInstance().getReference("Users").child(root);
        rootReference.child("Invitation").setValue("");
        rootReference.child("AESKey").setValue("");
        rootReference.child("PublicKey").setValue("");
        rootReference.child("MAC").setValue("");

        DatabaseReference receiverReference = FirebaseDatabase.getInstance().getReference("Users").child(receiver);
        receiverReference.child("Invitation").setValue("");
        receiverReference.child("AESKey").setValue("");
        receiverReference.child("PublicKey").setValue("");
        receiverReference.child("MAC").setValue("");

    }

    public void sendMessage() {
        String originalMessage = chat_message.getText().toString();
        Log.i("MessagingPage.java", "Original Message: " + originalMessage);
        String message = chat_message.getText().toString();

        // generate AESKey
        AESKey = securityCollection.generateAESKey();

        // encrypt AESKey with receiver's public key
        String cipherAESKey = securityCollection.encrypt(AESKey, receiverPublicKey);
        Log.i("MessagingPage.java", "AES Key: " + cipherAESKey);

        // encrypt message with receiver's public key
        message = securityCollection.encrypt(chat_message.getText().toString(), receiverPublicKey);
        Log.i("MessagingPage.java", "Encrypted Message: " + message);

        // generate MAC with encrypted message and original AESKey
        String MAC = securityCollection.generateMAC(message, AESKey);
        Log.i("MessagingPage.java", "MAC tag: " + MAC);

        // send MAC
        DatabaseReference receiverMACReference = reference.child(receiver).child("MAC");
        receiverMACReference.setValue(MAC);

        // send encrypted AESKey
        DatabaseReference receiverAESKeyReference = reference.child(receiver).child("AESKey");
        receiverAESKeyReference.setValue(cipherAESKey);

        // send message
        DatabaseReference receiverMessageReference = reference.child(receiver).child("Message");
        receiverMessageReference.setValue(message);

        // remove public key from server
        referenceForRootPublicKey.setValue("");


        MessageRecord messageRecord = new MessageRecord(originalMessage, 1);
        record.add(messageRecord);
        recyclerView.smoothScrollToPosition(record.size() - 1);
        mAdapter.notifyDataSetChanged();

        chat_message.setText("");


    }
}
